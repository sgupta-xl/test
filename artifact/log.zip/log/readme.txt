Your XL Deploy log files will be written in this directory.
